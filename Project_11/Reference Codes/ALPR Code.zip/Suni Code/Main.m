clc ;
clear all;
close all;
%% general settings ...
fontsize = 14;

%% IMAGE ACQUISITION ...
%  pick the image and load it..

 [filename, pathname] = uigetfile( ...
       {'*.jpg;*.tif;*.tiff;*.png;*.bmp', 'All image Files (*.jpg, *.tif, *.tiff, *.png, *.bmp)'}, ...
        'Pick a file');
f = fullfile(pathname, filename);
disp('Reading image');

rgbimage = imread(f);                          %read image ...
figure, imshow(rgbimage);
title('input color image');
impixelinfo;

gray=rgb2gray(rgbimage);                        % Converting the RGB (color) image to gray (intensity).
figure,imshow(gray);
title('grayscale image');
impixelinfo;

resize = imresize(gray,[640 480]);           % resize image...
figure, imshow(resize);
title('input resized image');
impixelinfo;

MFI = medfilt2(resize,[3 3]) ;                           %Median filter is used...              
figure, imshow(MFI);
impixelinfo;
title('Filtered image');

SE = strel('rectangle',[3 25]) 
tophatFiltered = imtophat(MFI,SE);        % Morphological TOP_HOT Filter...
figure,imshow(tophatFiltered);
title('Morphological TOP_HOT Filter');
impixelinfo;

level = graythresh(tophatFiltered);            % Thresholding by Otsu's method...
BW = im2bw(tophatFiltered,level);              % Binarization...
figure,imshow(BW);
title('Binarization');
impixelinfo;

SE = strel('rectangle',[2 4]);                % Morphological Opening...
J = imopen(BW,SE);
figure,imshow(J);
title('Morphological Opening');

SE = strel('rectangle',[3 11]);                % Morphological Closing...
JJ = imclose(J,SE);
figure,imshow(JJ);
title('Morphological Closing');

BW2 = imfill(JJ,'holes')
figure,imshow(BW2);
title('Fill image regions and holes');

conn = conndef(3,'maximal')
BW3 = bwareaopen(BW2,1500,conn);
figure,imshow(BW3);
title('Remove small objects from binary image');

figure;
imcontour(BW3);

s=regionprops(BW3,'Area','BoundingBox','MajorAxisLength','Orientation','MinorAxisLength');
[hh,ii] = sort([s.Area],'descend');
[sortedS, sortIndexes] = sort([s.MajorAxisLength],'descend');
[hi,ih] = sort([s.Orientation]);
[sorted, sortIndexe] = sort([s.MinorAxisLength],'descend');

out = imcrop(resize,s(ii(1)).BoundingBox); 
figure,imshow(out);
title('out image');

outt = imcrop(resize,s(sortIndexes(1)).BoundingBox); 
figure,imshow(outt);
title('outt image');
% 
% outto = imcrop(resize,s(ih(1)).BoundingBox); 
% figure,imshow(outto);
% title('outto image');
% 
% outto0 = imcrop(resize,s(sortIndexe(1)).BoundingBox); 
% figure,imshow(outto0);
% title('outto0 image');

